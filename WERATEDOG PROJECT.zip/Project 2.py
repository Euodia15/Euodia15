#!/usr/bin/env python
# coding: utf-8

# ### Import Libraries 

# In[1]:


import pandas as pd
import numpy as  np
import requests 
import tweepy
import os
import json
import re
import time
import warnings

import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')

import seaborn as sns
sns.set_style('whitegrid')

import plotly 
import plotly.express as px
import plotly.graph_objs as go
import plotly.offline as py
from plotly.offline import iplot
from plotly.subplots import make_subplots
import plotly.figure_factory as ff


# ### Enhanced Twitter Archive

# In[2]:


twit_arc = pd.read_csv('twitter-archive-enhanced.csv')


# ### Tweet Image Predictions

# In[3]:


url = "https://d17h27t6h515a5.cloudfront.net/topher/2017/August/599fd2ad_image-predictions/image-predictions.tsv"
response = requests.get(url)

with open('image_predictions.tsv', mode='wb') as file:
    file.write(response.content)
image_predictions=pd.read_csv('image_predictions.tsv', sep='\t')


# ### Twitter API

# In[4]:


import tweepy
from tweepy import OAuthHandler
import json
from timeit import default_timer as timer

consumer_key= ''
consumer_secret=''
access_token=''
access_secret=''

# authorization of consumer key and consumer secret
auth=OAuthHandler('u7DV90CjkGigqXurSyh8PxvoH','6sy6GAnQgDEI6mjDooZFewLUPeSyXntbv4QWAEDxVhAtqh3fW0')

# set access to user's access key and access secret 
auth.set_access_token('1516391561218646018-eI5XsZIK16oCNaKGsbBzWSDMhRfJez','Sb0KmtqEFmucvqAbdBoG23V4kfaknyXdN268RY37sGDfA')

# calling the api 
api= tweepy.API(auth, wait_on_rate_limit= True)
print(api)

test=[]

tweet_ids=list(twit_arc.tweet_id)
with open ('tweet_json.txt', 'w') as outfile:
    for tweet_id in tweet_ids:
        try:
            tweet=api.get_status(tweet_id,tweet_mode='extended')
            x={'tweet_id':tweet.id,'retweet_count':tweet.retweet_count,
           'favourite_count':'tweet.favourite_count'}
            test.append(x)
            json.dump(tweet._json, outfile)
            outfile.write('\n')
        except tweepy.TweepyException as e:
           #print ("Fail", e)
            pass


# In[5]:


tweets_info = []

with open ('tweet_json.txt') as file:
    for line in file:
        tweets_info.append(json.loads(line))


# In[6]:


for i in range(0,len(tweets_info)):
    print(tweets_info[i])


# In[7]:


tweets_info= pd.DataFrame(tweets_info, columns= ['id', 'retweet_count','favourite_count'])
tweets_info.head()


# In[8]:


tweets_info.to_csv('tweets_info.csv', index= False)


# In[9]:


tweets_info.head()


# In[10]:


tweets_info.tail()


# In[11]:


tweets_info.info()


# # Assessing

# ### a. Assessing Enhanced Twitter Archive

# In[12]:


twit_arc.head()


# In[13]:


twit_arc.sample(10)


# In[14]:


twit_arc.tail()


# In[15]:


twit_arc.info()


# In[16]:


twit_arc.describe()


# In[17]:


twit_arc['source'].value_counts()


# In[18]:


#sort by denominator values
twit_arc['rating_denominator'].value_counts()


# In[19]:


twit_arc['rating_numerator'].value_counts()


# In[20]:


twit_arc[twit_arc.rating_numerator <10].tweet_id


# In[21]:


twit_arc.rating_denominator.describe()
#some denominators have a 0 value


# In[22]:


#Records which are retweets
len(twit_arc[twit_arc.retweeted_status_timestamp.isnull()== False])


# In[23]:


#check for duplicate values
sum(twit_arc.duplicated())


# In[24]:


twit_arc.name.value_counts()


# # Observations For Enhanced Twitter Archive
# 
# ## Quality
# 
#     * There are retweets present in the data
#     * Dog names are not consistent
#     * ID variables are sometimes integers or floats (numeric)
#     * Column names are not always meaningful 
#     * Retweeted_status_timestamp is not a datetime variable
#     * Source values are formatted as <a href=url <a/>
#     * Some rating numerators less than 10
#     * "retweeted_status" variables are numeric
#     * Some rating denominators are not equal 10
# 
#    
# ## Structure
# 
#     * Doggo,floofer,pupper and puppo all refer to the same measurement "dog stage"
#     * Source and expanded urls have several information
#     * There is more than one stage filled for individual dogs

# ### b. Assessing Tweet Image Predictions

# In[25]:


image_predictions.head()


# In[26]:


image_predictions.shape


# In[27]:


image_predictions.sample(10)


# In[28]:


image_predictions.info


# In[29]:


image_predictions.img_num.unique()


# In[30]:


sum(image_predictions.jpg_url.duplicated()==True)


# In[31]:


sum(image_predictions.duplicated())


# In[32]:


image_predictions['img_num'].value_counts()


# In[33]:


image_predictions.describe()


# # Observations For Tweet Image Predictions
# ## Quality
# 
#     * Some column names contain '_' and '-' instead of spaces
#     * Some names start with an uppercase while some start with a lowercase

# ### c. Assessing Twitter API

# In[34]:


tweets_info.head()


# In[35]:


tweets_info.tail()


# In[36]:


tweets_info.info()


# In[37]:


tweets_info.describe()


# In[38]:


sum(tweets_info.duplicated())


# # Observations For Twitter API
# ### Quality
# * Missing data (the archive dataset has 2356 ids but only 2354 show up)

# #  Clean

# ## i. Twitter Archive

# ### a. DataFrame Copy

# In[39]:


twit_arc_copy= twit_arc.copy()
image_predic1= image_predictions.copy()
tweets_infoo= tweets_info.copy()


# ### b. Drop unrequired columns

# In[40]:


twit_arc_copy['dog_stage']=twit_arc_copy['text'].str.extract('(doggo|floofer|pupper|puppo)')


# In[41]:


twit_arc_copy = twit_arc_copy.drop(columns=['doggo','floofer', 'pupper','puppo'])
twit_arc_copy.head()


# ### c. Delete rows that represent retweets

# In[42]:


twit_arc_copy = twit_arc_copy[twit_arc_copy.retweeted_status_id.isnull()]
twit_arc_copy.info()


# ### d. Convert invalid names to Nan

# In[43]:


twit_arc_copy[twit_arc_copy.name.str.islower()==True]['name'].unique()


# In[44]:


faulty = ['such', 'a', 'quite', 'not', 'one', 'incredibly', 'very', 'my',
       'his', 'an', 'actually', 'just', 'getting', 'mad', 'this',
       'unacceptable', 'all', 'old', 'infuriating', 'the', 'by',
       'officially', 'life', 'light', 'space']


# In[45]:


for x in faulty:
    twit_arc_copy.name.replace(x, 'None', inplace= True)


# In[46]:


twit_arc_copy.name.unique()


# In[47]:


twit_arc_copy.rating_denominator= twit_arc_copy['rating_denominator']=10


# In[48]:


twit_arc_copy.rating_denominator.unique()


# ### e. Coverting tweet_id to string

# In[49]:


twit_arc_copy.tweet_id = twit_arc_copy.tweet_id.astype(str)


# In[50]:


twit_arc_copy.info() 


# ### f. Change timestamp coloumns to date

# In[51]:


twit_arc_copy['timestamp']=pd.to_datetime(twit_arc_copy['timestamp'])
twit_arc_copy['retweeted_status_timestamp']=pd.to_datetime(twit_arc_copy['retweeted_status_timestamp'])


# ## ii. Image Predictions

# ### a.Capitalize First Alphabet Of p1, p2 and p3

# In[52]:


image_predic1.p1 = image_predic1.p1.str.capitalize()
image_predic1.p2 = image_predic1.p2.str.capitalize()
image_predic1.p3 = image_predic1.p3.str.capitalize()


# In[53]:


image_predic1.head()


# ### b. Replce '-' And '_' With Spaces

# In[54]:


image_predic1.p1 = image_predic1.p1.str.replace('-',' ')
image_predic1.p2 = image_predic1.p2.str.replace('-',' ')
image_predic1.p3 = image_predic1.p3.str.replace('-',' ')


# In[55]:


image_predic1.p1 = image_predic1.p1.str.replace('_',' ')
image_predic1.p2 = image_predic1.p2.str.replace('_',' ')
image_predic1.p3 = image_predic1.p3.str.replace('_',' ')


# In[56]:


image_predic1.head()


# ## Twitter API

# #### Rows with missing entries were deleted earlier

# In[57]:


sum(tweets_info.retweet_count.isnull())


# # Renaming Columns 

# In[58]:


tweets_info.rename(columns={'id':'tweet_id', 'favorite_counts':'likes','retweet_counts':'retweets'}, inplace = True)


# In[59]:


tweets_info.head()


# In[60]:


tweets_info.info()


# ### Change format type from num to string

# In[61]:


twit_arc_copy['tweet_id']= twit_arc_copy['tweet_id'].astype('str')
image_predic1['tweet_id']= image_predic1['tweet_id'].astype('str')
tweets_info['tweet_id']= tweets_info['tweet_id'].astype('str')


# In[62]:


type(twit_arc_copy['tweet_id'].iloc[0])
type(image_predic1['tweet_id'].iloc[0])
type(tweets_info['tweet_id'].iloc[0])


# ### Combine the datasets

# In[63]:


df_merge= pd.merge(twit_arc_copy, image_predic1, on=['tweet_id'], how= 'inner')
df_merge= pd.merge(df_merge, tweets_info, on=['tweet_id'], how= 'inner')


# In[64]:


df_merge.info()


# ### Rename columns

# In[65]:


df_merge.rename(columns={'rating_numerator':'numerator','rating_denominator':'denominator'}, inplace= True)


# ### Drop unrequired columns

# In[66]:


df_merge.drop(['retweeted_status_id','retweeted_status_timestamp','retweeted_status_user_id'],axis= 1, inplace= True)


# In[67]:


pd.set_option('display.max_columns', None)


# In[68]:


df_merge.head()


# # Storing Data

# In[69]:


df_merge.to_csv('twitter_archive_master.csv', encoding='utf-8', index= False)
wrangled_project= pd.read_csv('twitter_archive_master.csv')


# In[70]:


wrangled_project.head()


# In[71]:


tweets_infoo.head()


# # Data Visualizing

# ### i. Relationship Between Favourite_count and Retweet_count 

# In[72]:


plt.figure(figsize=(12,10))
g = sns.boxplot(x='dog_stage', y= 'retweet_count', data= wrangled_project, palette= 'summer')
g.axes.set_title('Boxplot Between Dog Stages And Retweets', fontsize=20);


# ### Analysis 
# * There are more dogs in puppo category
# * There are more retweets in doggo category

# ### ii. Top 10 Most Popular Dog Breeds

# In[73]:


top_10 = wrangled_project[["retweet_count", "p3"]].sort_values(["retweet_count"], ascending=False)[:10]   
top_10
fig = px.scatter(top_10, y= 'p3', x='retweet_count', hover_data = top_10[[ 'p3']], color='p3',
                 title = "Top 10 Most Popular Dog Breeds")
fig.show()


# ### Analysis
# * 'Whippet is the most retweeted dog breed

# ### iii. Amount of Each Dog Stage

# In[74]:


stages_df = twit_arc_copy.dog_stage.value_counts()


# In[75]:


stages_df


# In[76]:


plt.pie(stages_df, labels = ['Pupper','Doggo','Puppo','Floofer'], 
        autopct='%0.0f%%', 
        shadow= False, 
        explode = (0.1, 0.3, 0.2,0.1)
       )
plt.title("Dog Stage Percentage Analysis")
plt.axis('equal')


# ### Analysis
# 
# * Pupper has the highest percentage
# * Floofer has the least percentage 

# In[ ]:




